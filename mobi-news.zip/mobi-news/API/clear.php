<?php
unlink('dispatch.lock');
unlink('send.lock');
?>