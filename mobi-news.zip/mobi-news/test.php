<?php
require_once ('include/config.php');
require_once ('include/MysqliDb.php');
require_once ('include/functions.php');
require_once ('include/smppclass.sm.php');

send_breaking_news_now();