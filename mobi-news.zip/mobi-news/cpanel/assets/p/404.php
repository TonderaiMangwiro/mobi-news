
<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <center>
                    <img src="assets/img/error404.png" width="300"/>
                    <h2><i class="fa fa-warning"></i> 404 Not Found Error.</h2>
                    <hr style="width:50%;"/>
                    <h5>The requested page was not found on this server. Please make sure you typed the address correctly.</h5>
                </center>
            </div>
        </div><!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
