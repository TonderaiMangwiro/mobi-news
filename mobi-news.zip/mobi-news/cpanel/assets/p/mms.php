
<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h2>Send MMS News</h2>   
                <h5>Unavailable at this time...</h5>
            </div>
        </div><!-- /. ROW  -->
        <hr/>
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
