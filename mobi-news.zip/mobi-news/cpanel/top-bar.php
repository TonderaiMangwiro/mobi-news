<nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom:0;background:#FFF;">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php"><img src="../images/logo-white.png" width="180"></a>
    </div>
    <div style="padding:15px 15px 5px 50px; font-size:16px;">
        <img src="assets/img/mg.jpg" width="100" style="margin-left:10px;">
        <img src="assets/img/nd.jpg" width="100" style="margin-left:10px;">
        <img src="assets/img/vd.jpg" width="100" style="margin-left:10px;">
        <img src="assets/img/eco.png" width="100" style="margin-left:10px;">
        <img src="assets/img/mtn.jpg" width="100" style="margin-left:10px;">
        <!--
        <img src="assets/img/tel.jpg" width="100" style="margin-left:10px;">
        <img src="assets/img/net.jpg" width="100" style="margin-left:10px;">
        -->
        <span class="pull-right">
            You are logged in as <b><a href="index.php?p=profile"><?php echo $oUSR->get_name(); ?></a></b>. &nbsp; <a href="index.php?p=logout" class="btn btn-danger square-btn-adjust">Logout</a>
        </span>
    </div>
</nav><!-- /. NAV TOP  -->
